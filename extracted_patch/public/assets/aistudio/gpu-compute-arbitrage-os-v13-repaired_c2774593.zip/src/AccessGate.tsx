import React, { useState } from 'react';
import App from './App';
import { signIn } from './apiSession';
export default function AccessGate() {
  const [ready, setReady] = useState(false);
  const [key, setKey] = useState('');
  const [error, setError] = useState('');
  if (ready) return <App />;
  return <main className="min-h-screen bg-slate-950 text-white flex items-center justify-center p-6">
    <form className="w-full max-w-md space-y-4" onSubmit={async e => {
      e.preventDefault(); setError('');
      try { await signIn(key); setKey(''); setReady(true); } catch (err: any) { setError(err.message); }
    }}>
      <h1 className="text-2xl font-bold">GPU Compute Arbitrage OS</h1>
      <p>Enter your server access key. Owner actions require OWNER_API_KEY. Refreshing signs you out.</p>
      <label className="block">Access key<input aria-label="Access key" type="password" autoComplete="off" required value={key}
        onChange={e => setKey(e.target.value)} className="block w-full mt-2 p-3 bg-slate-900 rounded border border-slate-600" /></label>
      <button className="px-4 py-2 rounded bg-cyan-700">Sign in</button>
      {error && <p role="alert">{error}</p>}
    </form>
  </main>;
}
