import React, { useEffect, useState } from 'react';

async function api(path: string, body?: unknown) {
  const res = await fetch('/api/' + path, body === undefined ? {} : {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}
const field = 'w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-white';
const button = 'rounded-lg bg-cyan-700 px-4 py-2 text-sm font-semibold hover:bg-cyan-600 disabled:opacity-50';
const card = 'rounded-xl border border-slate-800 bg-slate-900 p-5 space-y-4';
const date = (value: string) => value ? new Date(value).toLocaleString('en-ZA', { timeZone: 'Africa/Johannesburg' }) + ' SAST' : 'Not verified';
const amount = (value: number) => Number.isFinite(value) ? value.toLocaleString('en-ZA', { maximumFractionDigits: 8 }) : 'Unavailable';

function Calculator() {
  const [values, setValues] = useState({ buy: 1.74, sell: 2.85, hours: 24, gpus: 1, utilisation: 50, overhead: 0.15, fee: 3 });
  const set = (name: string, value: string) => setValues(prev => ({ ...prev, [name]: Number(value) }));
  const valid = Object.values(values).every(Number.isFinite) && values.buy >= 0 && values.sell > 0 && values.hours > 0 && Number.isInteger(values.gpus) && values.gpus > 0 && values.utilisation >= 0 && values.utilisation <= 100 && values.overhead >= 0 && values.fee >= 0 && values.fee <= 100;
  const revenue = values.sell * values.hours * values.gpus * values.utilisation / 100;
  const rental = values.buy * values.hours * values.gpus;
  const overhead = values.overhead * values.hours * values.gpus;
  const fees = revenue * values.fee / 100;
  const profit = revenue - rental - overhead - fees;
  const labels: Record<string, string> = { buy: 'Rental USD / GPU-hour', sell: 'Customer USD / GPU-hour', hours: 'Rental hours', gpus: 'Number of GPUs', utilisation: 'Paid utilisation %', overhead: 'Other costs USD / rented GPU-hour', fee: 'Payment fee % of revenue' };
  return <section className={card}>
    <h2 className="text-xl font-bold">Profit scenario calculator</h2>
    <p className="text-slate-400">Illustrative inputs. Rental is charged for every rented hour; revenue uses paid utilisation. Include storage, bandwidth, support and risk reserves in other costs. Tax and exchange costs require separate allowance.</p>
    <div className="grid gap-4 sm:grid-cols-2">{Object.entries(values).map(([key, value]) => <label key={key} className="text-sm text-slate-300">{labels[key]}<input className={field} type="number" min="0" step={key === 'gpus' ? '1' : 'any'} value={value} onChange={e => set(key, e.target.value)} /></label>)}</div>
    {valid ? <div className="grid gap-3 sm:grid-cols-4">{[['Revenue', revenue], ['Rental', rental], ['Other costs + fees', overhead + fees], ['Estimated result', profit]].map(([name, value]) => <div key={String(name)} className="rounded-lg bg-slate-950 p-4"><p className="text-slate-400 text-sm">{name}</p><p className="text-xl font-mono">${Number(value).toFixed(2)}</p></div>)}</div> : <p role="alert" className="text-amber-300">Enter valid nonnegative costs, positive hours and GPU count, and percentages from 0–100.</p>}
    <p className="text-amber-200 text-sm">This estimate cannot create a contract, balance, payment or withdrawable profit.</p>
  </section>;
}

export default function App() {
  const [tab, setTab] = useState('Overview');
  const [account, setAccount] = useState<any>(null);
  const [quotes, setQuotes] = useState<any[]>([]);
  const [providers, setProviders] = useState<any[]>([]);
  const [bootstrap, setBootstrap] = useState<any>(null);
  const [ledger, setLedger] = useState<any>(null);
  const [logs, setLogs] = useState<any[]>([]);
  const [groq, setGroq] = useState<any>(null);
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const [key, setKey] = useState('');
  const [service, setService] = useState('Groq');
  const [question, setQuestion] = useState('');
  const [reply, setReply] = useState('');
  const refresh = async () => {
    setBusy(true); setMessage('');
    const requests: Array<[string, (value: any) => void]> = [
      ['binance/account', setAccount], ['arbitrage/quotes', setQuotes], ['bootstrap', setBootstrap],
      ['ledger/cfo-breakdown', setLedger], ['system/real-logs', setLogs], ['ai/status', setGroq],
      ['providers/balances', value => setProviders(value.providers || [])],
    ];
    const results = await Promise.allSettled(requests.map(async ([path, save]) => save(await api(path))));
    const failures = results.flatMap(result => result.status === 'rejected' ? [result.reason.message] : []);
    if (failures.length) setMessage(failures.join(' · '));
    setBusy(false);
  };
  useEffect(() => { void refresh(); }, []);
  const action = async (run: () => Promise<void>) => {
    setBusy(true); setMessage('');
    try { await run(); } catch (err: any) { setMessage(err.message); } finally { setBusy(false); }
  };
  const configure = () => action(async () => {
    if (service === 'Groq') {
      await api('ai/config', { apiKey: key }); setKey('');
      const status = await api('ai/verify', {}); setGroq(status);
      setMessage('Groq responded successfully. Verification expires after five minutes.');
    } else {
      const result = await api(service === 'RunPod' ? 'providers/verify-runpod' : 'providers/verify-lightning', { apiKey: key });
      setKey(''); if (!result.success) throw new Error(result.error || 'Provider verification failed.');
      setMessage(`${service} response verified. Reported credits: ${result.balanceUsd}. Credits are separate from withdrawable cash.`);
    }
  });
  return <div className="min-h-screen bg-[#090d16] text-slate-100">
    <header className="border-b border-slate-800 px-5 py-5"><div className="mx-auto max-w-6xl flex items-center justify-between gap-4 flex-wrap">
      <div><p className="text-cyan-400 text-xs font-mono tracking-widest">COMPUTE OPERATIONS</p><h1 className="text-xl font-bold">GPU Arbitrage OS</h1></div>
      <button className={button} disabled={busy} onClick={refresh}>{busy ? 'Checking…' : 'Refresh evidence'}</button>
    </div></header>
    <main className="mx-auto max-w-6xl p-5 space-y-5">
      <div role="status" className="rounded-lg border border-amber-800 bg-amber-950/50 p-4 text-amber-100"><strong>Live business execution is blocked.</strong> Provider orders, customer acceptance and durable settlement still require implementation and live validation. No autonomous earnings are established.</div>
      <nav className="flex gap-2 flex-wrap" aria-label="Dashboard">{['Overview', 'Quotes', 'Treasury', 'Calculator', 'AI & connections', 'System', 'Logs'].map(name => <button key={name} onClick={() => setTab(name)} className={'px-3 py-2 rounded-lg text-sm ' + (tab === name ? 'bg-cyan-900 text-cyan-100' : 'bg-slate-900 text-slate-400')}>{name}</button>)}</nav>
      {message && <p role="alert" className="rounded-lg border border-slate-700 p-3 break-words">{message}</p>}
      {tab === 'Overview' && <>
        <div className="grid gap-4 sm:grid-cols-3">{[['Exchange account', account?.isLiveApiKey ? 'Read verified' : 'Unavailable'], ['Executable GPU quotes', '0'], ['Verified active jobs', '0']].map(([name, value]) => <section key={name} className={card}><p className="text-slate-400 text-sm">{name}</p><p className="text-2xl font-bold">{value}</p></section>)}</div>
        <section className={card}><h2 className="text-lg font-bold">What must happen before earnings are real</h2><ol className="list-decimal ml-5 space-y-2 text-slate-300"><li>A customer accepts an order at an agreed price.</li><li>A provider supplies a fresh quote and a real job reference.</li><li>The work completes and its result is delivered.</li><li>A provider verifies the customer payment.</li><li>Actual rental and all other costs are matched to that order.</li></ol></section>
      </>}
      {tab === 'Quotes' && <section className={card}><h2 className="text-xl font-bold">GPU reference catalogue</h2><p className="text-slate-400">These fixed benchmark entries have no verified retrieval date. They are not live offers or customer demand. Refreshing does not update their source prices.</p><div className="overflow-auto"><table className="w-full text-sm text-left"><thead className="text-slate-400"><tr>{['GPU', 'Provider', 'USD / GPU-hour', 'Source date', 'Execution'].map(h => <th key={h} className="p-3">{h}</th>)}</tr></thead><tbody>{quotes.map(q => <tr key={q.quoteId} className="border-t border-slate-800"><td className="p-3">{q.gpuModel}</td><td className="p-3">{q.providerName}</td><td className="p-3">{q.hourlyRateUsd}</td><td className="p-3">{date(q.retrievedAt)}</td><td className="p-3 text-amber-200">Blocked · {q.quoteSource}</td></tr>)}</tbody></table></div></section>}
      {tab === 'Treasury' && <>
        <section className={card}><h2 className="text-xl font-bold">Exchange asset quantities</h2><p className="text-slate-400">{account?.notes || 'Awaiting response.'}</p><p className="text-sm">Last successful account read: {date(account?.lastSyncAt)}</p><div className="grid gap-3 sm:grid-cols-5">{['usdt', 'usdc', 'btc', 'eth', 'bnb'].map(asset => <div key={asset} className="bg-slate-950 rounded-lg p-3"><p className="text-slate-400">{asset.toUpperCase()}</p><p className="font-mono">{account?.isLiveApiKey ? amount(account[asset + 'Balance']) : 'Unavailable'}</p></div>)}</div><p>Full USD valuation, margin capacity, account ownership and deposit addresses are unverified.</p><p className="text-amber-200">Deposits, withdrawals, borrowing and profit sweeps are unavailable in this build.</p></section>
        <section className={card}><h2 className="font-bold">Provider credits</h2><p className="text-slate-400">Compute credits are separate from cash and profit.</p>{providers.map(provider => <div key={provider.providerId} className="flex flex-wrap justify-between gap-2 border-t border-slate-800 py-3"><span>{provider.providerName}</span><span className="text-sm text-slate-400">{provider.verificationLevel} · {provider.isLiveConnected && provider.balance !== null ? `${amount(provider.balance)} ${provider.currency}` : 'Balance unavailable'}</span></div>)}</section>
      </>}
      {tab === 'Calculator' && <Calculator />}
      {tab === 'AI & connections' && <div className="grid gap-5 md:grid-cols-2">
        <section className={card}><h2 className="text-lg font-bold">Verify a connection</h2><p className="text-slate-400 text-sm">Owner access required. Enter a service API key; it is kept in server memory for this process. For persistence, use deployment secrets and restart.</p>
          <label className="block">Service<select className={field} value={service} onChange={e => { setService(e.target.value); setKey(''); }}>{['Groq', 'RunPod', 'Lightning AI'].map(name => <option key={name}>{name}</option>)}</select></label>
          <label className="block">Service API key<input type="password" autoComplete="off" className={field} value={key} onChange={e => setKey(e.target.value)} /></label>
          <button disabled={busy || !key.trim()} className={button} onClick={configure}>Save and verify</button>
          <p className="text-sm">Groq: {groq?.status || 'Unknown'} · {groq?.model || 'No model'}</p><p className="text-sm text-slate-400">Last Groq response: {date(groq?.verifiedAt)}</p>
          <p className="text-sm text-slate-400">Binance credentials belong in BINANCE_API_KEY and BINANCE_SECRET_KEY on the server. Vast.ai remains a non-executable reference adapter.</p>
        </section>
        <section className={card}><h2 className="text-lg font-bold">Advisory AI</h2><p className="text-slate-400 text-sm">AI cannot verify customers, payments or jobs. An unavailable service returns an error.</p><label className="block">Question<textarea className={field} rows={4} value={question} onChange={e => setQuestion(e.target.value)} /></label><button disabled={busy || !question.trim()} className={button} onClick={() => action(async () => { const result = await api('ai/copilot', { messages: [{ role: 'user', content: question }] }); setReply(result.reply); setGroq(await api('ai/status')); })}>Ask Groq</button>{reply && <p className="whitespace-pre-wrap text-slate-300">{reply}</p>}</section>
      </div>}
      {tab === 'System' && <div className="grid gap-5 md:grid-cols-2"><section className={card}><h2 className="text-lg font-bold">Startup checks</h2><p>Database: {bootstrap?.databaseReadiness?.isReady ? 'Connected at startup' : 'Unavailable'}</p><p>Migrations: {bootstrap?.databaseMigrations?.success ? 'Passed' : 'Not verified'}</p><p>Verified worker fleet: 0</p><p>Background repository publishing: disabled</p><p>HTTPS: configure a trusted TLS ingress before external use.</p><p className="text-slate-400 text-sm">The health endpoint proves the HTTP process responds. Business readiness remains blocked.</p></section><section className={card}><h2 className="text-lg font-bold">Ledger evidence</h2><p>Verified customer receipts: {ledger?.metrics?.reconciledCustomerReceipts?.invoicesPaidCount ?? 'Unavailable'}</p><p>Ledger entries: {ledger?.metrics?.internalLedgerBalances?.entriesCount ?? 'Unavailable'}</p><p>Reconciliation: {ledger?.reconciliationAudit?.status ?? 'Unavailable'}</p><p className="text-slate-400 text-sm">Current financial persistence is a local file. Transactional database settlement and end-to-end reconciliation remain release blockers.</p></section></div>}
      {tab === 'Logs' && <section className={card}><h2 className="text-lg font-bold">Recorded system events</h2>{logs.length ? logs.map(log => <div key={log.id} className="border-t border-slate-800 py-3 text-sm"><p className="text-cyan-300">{log.timestamp} · {log.service}</p><p className="break-words text-slate-300">{log.message}</p></div>) : <p className="text-slate-400">No recorded events.</p>}</section>}
    </main>
  </div>;
}
