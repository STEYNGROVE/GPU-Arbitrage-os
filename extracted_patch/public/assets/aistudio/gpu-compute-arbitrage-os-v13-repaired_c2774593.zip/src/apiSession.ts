let token = '';
const nativeFetch = window.fetch.bind(window);
export async function signIn(value: string) {
  const response = await nativeFetch('/api/session', { headers: { Authorization: `Bearer ${value.trim()}` } });
  if (!response.ok) throw new Error('Access key was rejected. Use a configured server API or owner key.');
  token = value.trim();
}
window.fetch = (input, init) => {
  const request = new Request(input instanceof Request ? input : new URL(String(input), location.href), init);
  const url = new URL(request.url);
  if (token && url.origin === location.origin && url.pathname.startsWith('/api/')) {
    request.headers.set('Authorization', `Bearer ${token}`);
  }
  return nativeFetch(request);
};
