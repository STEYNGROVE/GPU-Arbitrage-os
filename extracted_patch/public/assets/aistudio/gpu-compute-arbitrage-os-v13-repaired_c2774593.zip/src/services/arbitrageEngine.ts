import {
  GPUHardware,
  Provider,
  ArbitrageOpportunity,
  ActiveContract,
  FleetWorker,
  DatabaseRelation,
  ExecutionLog,
  ArbitrageOrderRequest
} from '../types/arbitrage';

export const GPU_HARDWARE_CATALOG: GPUHardware[] = [
  {
    id: 'h100-sxm5',
    name: 'NVIDIA H100 SXM5',
    architecture: 'Hopper (GH100)',
    vramGb: 80,
    memoryBandwidthTb: 3.35,
    fp16Tflops: 1979,
    tdpWatts: 700,
    interconnect: 'NVLink 4.0 (900 GB/s)',
    baseMarketAvgRate: 2.15,
  },
  {
    id: 'h200-sxm',
    name: 'NVIDIA H200 SXM',
    architecture: 'Hopper (GH100)',
    vramGb: 141,
    memoryBandwidthTb: 4.8,
    fp16Tflops: 1979,
    tdpWatts: 700,
    interconnect: 'NVLink 4.0 (900 GB/s)',
    baseMarketAvgRate: 3.40,
  },
  {
    id: 'b200-blackwell',
    name: 'NVIDIA B200 Blackwell',
    architecture: 'Blackwell (GB200)',
    vramGb: 192,
    memoryBandwidthTb: 8.0,
    fp16Tflops: 4500,
    tdpWatts: 1000,
    interconnect: 'NVLink 5.0 (1,800 GB/s)',
    baseMarketAvgRate: 4.85,
  },
  {
    id: 'gh200-superchip',
    name: 'NVIDIA GH200 Grace Hopper',
    architecture: 'Hopper + Grace CPU',
    vramGb: 96,
    memoryBandwidthTb: 4.0,
    fp16Tflops: 1979,
    tdpWatts: 900,
    interconnect: 'NVLink-C2C (900 GB/s)',
    baseMarketAvgRate: 2.95,
  },
  {
    id: 'a100-80gb-sxm4',
    name: 'NVIDIA A100 80GB SXM4',
    architecture: 'Ampere (GA100)',
    vramGb: 80,
    memoryBandwidthTb: 2.0,
    fp16Tflops: 624,
    tdpWatts: 400,
    interconnect: 'NVLink 3.0 (600 GB/s)',
    baseMarketAvgRate: 1.45,
  },
  {
    id: 'l40s-48gb',
    name: 'NVIDIA L40S 48GB',
    architecture: 'Ada Lovelace (AD102)',
    vramGb: 48,
    memoryBandwidthTb: 0.86,
    fp16Tflops: 733,
    tdpWatts: 350,
    interconnect: 'PCIe Gen 4 x16',
    baseMarketAvgRate: 0.95,
  },
  {
    id: 'rtx-4090-24gb',
    name: 'NVIDIA RTX 4090 24GB',
    architecture: 'Ada Lovelace (AD102)',
    vramGb: 24,
    memoryBandwidthTb: 1.01,
    fp16Tflops: 330,
    tdpWatts: 450,
    interconnect: 'PCIe Gen 4 x16',
    baseMarketAvgRate: 0.44,
  },
  {
    id: 'mi300x-192gb',
    name: 'AMD Instinct MI300X',
    architecture: 'CDNA 3',
    vramGb: 192,
    memoryBandwidthTb: 5.3,
    fp16Tflops: 2610,
    tdpWatts: 750,
    interconnect: 'Infinity Fabric 4.0 (896 GB/s)',
    baseMarketAvgRate: 2.65,
  },
];

export const PROVIDERS_CATALOG: Provider[] = [
  {
    id: 'vast-ai',
    name: 'Vast.ai Spot Fabric',
    type: 'Decentralized Spot',
    region: 'Global P2P',
    datacenterPUE: 1.15,
    energySource: 'Grid Mix',
    preemptionRatePerHour: 0.042,
    apiLatencyMs: 24,
    reliabilityScore: 92.4,
  },
  {
    id: 'runpod-spot',
    name: 'RunPod Community & Secure',
    type: 'Specialized Cloud',
    region: 'US-Central / EU-West',
    datacenterPUE: 1.18,
    energySource: 'Grid Mix',
    preemptionRatePerHour: 0.021,
    apiLatencyMs: 18,
    reliabilityScore: 97.2,
  },
  {
    id: 'lambda-labs',
    name: 'Lambda Cloud On-Demand',
    type: 'Specialized Cloud',
    region: 'US-West (SLC, SFO)',
    datacenterPUE: 1.12,
    energySource: 'Hydro',
    preemptionRatePerHour: 0.005,
    apiLatencyMs: 12,
    reliabilityScore: 99.1,
  },
  {
    id: 'coreweave',
    name: 'CoreWeave Enterprise HPC',
    type: 'Specialized Cloud',
    region: 'US-East (NJ, VA, NC)',
    datacenterPUE: 1.08,
    energySource: 'Nuclear / Clean',
    preemptionRatePerHour: 0.001,
    apiLatencyMs: 9,
    reliabilityScore: 99.95,
  },
  {
    id: 'fluidstack',
    name: 'FluidStack Global Mesh',
    type: 'Decentralized Spot',
    region: 'EU-North (Stockholm)',
    datacenterPUE: 1.06,
    energySource: 'Hydro',
    preemptionRatePerHour: 0.035,
    apiLatencyMs: 31,
    reliabilityScore: 94.8,
  },
  {
    id: 'crusoe-cloud',
    name: 'Crusoe Clean Compute',
    type: 'Green Datacenter',
    region: 'US-North Dakota (Flare gas)',
    datacenterPUE: 1.05,
    energySource: 'Geothermal',
    preemptionRatePerHour: 0.008,
    apiLatencyMs: 22,
    reliabilityScore: 98.6,
  },
  {
    id: 'prime-intellect',
    name: 'Prime Intellect Decentralized',
    type: 'Decentralized Spot',
    region: 'Distributed Mesh',
    datacenterPUE: 1.20,
    energySource: 'Grid Mix',
    preemptionRatePerHour: 0.039,
    apiLatencyMs: 40,
    reliabilityScore: 93.1,
  },
  {
    id: 'nebius-cloud',
    name: 'Nebius AI Studio Pods',
    type: 'Specialized Cloud',
    region: 'EU-Central (Mäntsälä, Finland)',
    datacenterPUE: 1.04,
    energySource: 'Hydro',
    preemptionRatePerHour: 0.002,
    apiLatencyMs: 14,
    reliabilityScore: 99.8,
  },
  {
    id: 'aws-ec2',
    name: 'AWS EC2 P5/G6 Instances',
    type: 'Hyperscaler',
    region: 'us-east-1 (N. Virginia)',
    datacenterPUE: 1.15,
    energySource: 'Grid Mix',
    preemptionRatePerHour: 0.001,
    apiLatencyMs: 11,
    reliabilityScore: 99.99,
  },
  {
    id: 'gcp-compute',
    name: 'Google Cloud A3 High (H100)',
    type: 'Hyperscaler',
    region: 'us-central1 (Iowa)',
    datacenterPUE: 1.10,
    energySource: 'Nuclear / Clean',
    preemptionRatePerHour: 0.001,
    apiLatencyMs: 10,
    reliabilityScore: 99.99,
  },
];

export const INITIAL_ARBITRAGE_OPPORTUNITIES: ArbitrageOpportunity[] = [];

// Clock time and a projected spread do not establish earned profit.
export function computeContractAccruedPnL(contract: any, now: number = Date.now()): number {
  return 0;
}

const c1Start = Date.now() - 48 * 3600 * 1000;
const c2Start = Date.now() - 72 * 3600 * 1000;
const c3Start = Date.now() - 24 * 3600 * 1000;
const c4Start = Date.now() - 18 * 3600 * 1000;

export const INITIAL_ACTIVE_CONTRACTS: ActiveContract[] = [];

// The 36 PostgreSQL database relations from PostgreSQL 'arbitrage_v13' catalog
export const POSTGRES_36_RELATIONS: DatabaseRelation[] = [];

export function generateInitialFleetWorkers(): FleetWorker[] { return []; }

export function generateInitialLogs(): ExecutionLog[] { return []; }

export const INITIAL_BINANCE_ACCOUNT: import('../types/arbitrage').BinanceAccount = {
  isConnected: false, ownerEmail: '', ownerName: 'Unverified account', binanceUid: '',
  subaccountName: '', kycStatus: 'UNVERIFIED', whitelistedIp: '', outboundEgressIp: '',
  recommendedWhitelistIps: [], accountType: 'NOT_CONNECTED', apiKeyMasked: '', apiPermissions: [],
  pingLatencyMs: 0, usdtBalance: 0, usdcBalance: 0, btcBalance: 0, ethBalance: 0,
  totalEquityUsd: 0, availableMarginUsd: 0, autoSweepProfits: false, sweepThresholdUsd: 0,
  vipTier: 'UNVERIFIED', makerFeeRate: 0, takerFeeRate: 0,
  verifiedDepositAddress: '', verifiedTronAddress: '',
};

export const DEPIN_TOKENS_LIST: import('../types/arbitrage').DePINToken[] = [
  {
    symbol: 'RENDER',
    name: 'Render Network',
    spotPriceUsd: 6.84,
    change24h: 4.82,
    binanceVolume24h: '$142.5M',
    impliedComputeGpu: 'RTX 4090 / A100 Distributed OctaneRender Nodes',
    futuresHedgingPair: 'RENDERUSDT PERP (20x)',
    openInterestUsd: '$48.2M',
  },
  {
    symbol: 'TAO',
    name: 'Bittensor Subnets',
    spotPriceUsd: 584.20,
    change24h: 8.15,
    binanceVolume24h: '$210.8M',
    impliedComputeGpu: 'H100 SXM5 / H200 Subnet 1 & Subnet 18 Validator Clusters',
    futuresHedgingPair: 'TAOUSDT PERP (25x)',
    openInterestUsd: '$94.6M',
  },
  {
    symbol: 'AKT',
    name: 'Akash Network Supercloud',
    spotPriceUsd: 3.92,
    change24h: 3.10,
    binanceVolume24h: '$41.2M',
    impliedComputeGpu: 'A100 80GB / L40S Open-Bid Kubernetes Leases',
    futuresHedgingPair: 'AKTUSDT PERP (15x)',
    openInterestUsd: '$18.4M',
  },
  {
    symbol: 'IO',
    name: 'io.net Cloud Mesh',
    spotPriceUsd: 2.45,
    change24h: 6.40,
    binanceVolume24h: '$86.5M',
    impliedComputeGpu: 'Apple Silicon + NVIDIA Consumer & Enterprise Hybrid Clustered Nodes',
    futuresHedgingPair: 'IOUSDT PERP (20x)',
    openInterestUsd: '$34.1M',
  },
  {
    symbol: 'ATH',
    name: 'Aethir Enterprise Cloud',
    spotPriceUsd: 0.082,
    change24h: 2.90,
    binanceVolume24h: '$64.1M',
    impliedComputeGpu: 'H100 SXM5 & Enterprise Cloud Gaming Edge Pods',
    futuresHedgingPair: 'ATHUSDT PERP (10x)',
    openInterestUsd: '$22.8M',
  },
  {
    symbol: 'FET',
    name: 'Artificial Superintelligence (ASI)',
    spotPriceUsd: 1.42,
    change24h: 1.85,
    binanceVolume24h: '$118.0M',
    impliedComputeGpu: 'Autonomous Agent Microservice Compute Workloads',
    futuresHedgingPair: 'FETUSDT PERP (20x)',
    openInterestUsd: '$52.0M',
  },
];

export const INITIAL_BINANCE_HEDGES: import('../types/arbitrage').BinanceHedgePosition[] = [];

export const INITIAL_BINANCE_TRANSFERS: import('../types/arbitrage').BinanceTransfer[] = [];
