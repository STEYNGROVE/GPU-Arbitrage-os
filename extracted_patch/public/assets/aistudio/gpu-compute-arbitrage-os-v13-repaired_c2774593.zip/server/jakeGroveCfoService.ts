import { Spot } from '@binance/connector';
import { config } from './config.ts';
import { financialLedger, type LedgerEntry } from './financialLedger.ts';


export interface BinanceAccountStatus {
  isConnected: boolean;
  isLiveApiKey: boolean;
  connectionStatus: 'CONNECTED_LIVE' | 'SANDBOX_SIMULATION' | 'BLOCKED_NO_KEYS' | 'ERROR';
  ownerEmail: string;
  ownerName: string;
  binanceUid: string;
  accountType: string;
  vipTier: string;
  apiKeyMasked: string;
  pingLatencyMs: number;
  usdtBalance: number;
  usdcBalance: number;
  btcBalance: number;
  ethBalance: number;
  bnbBalance: number;
  totalEquityUsd: number;
  availableMarginUsd: number;
  autoSweepProfits: boolean;
  sweptProfitsUsd?: number;
  rawSpotBalance?: number;
  lastSyncAt: string;
  permissions: string[];
  outboundEgressIp: string;
  whitelistedIp: string;
  verifiedDepositAddress: string;
  verifiedTronAddress?: string;
  isSimulated: boolean;
  notes: string;
}

export interface DePINTicker {
  symbol: string;
  pair: string;
  price: number;
  change24h: number;
  volume24h: string;
  high24h: number;
  low24h: number;
  source: 'BINANCE_LIVE_API' | 'BENCHMARK_FEED';
  retrievedAt: string;
}

export interface WithdrawalNetworkConfig {
  network: string;
  name: string;
  asset: string;
  address: string;
  memoRequired: boolean;
  expectedArrival: string;
  minWithdrawal: string;
  withdrawalFee: string;
  isDefault: boolean;
  blockExplorerBase: string;
  confirmationsRequired: number;
}

export interface WithdrawalResult {
  success: boolean;
  state: 'CONFIRMED' | 'SUBMITTED' | 'PENDING' | 'BLOCKED' | 'REJECTED' | 'FAILED';
  withdrawalId: string;
  amount: number;
  asset: string;
  network: string;
  targetAddress: string;
  txHash?: string;
  blockExplorerUrl?: string;
  confirmations: string;
  binanceUid: string;
  timestamp: string;
  isSimulated: boolean;
  message: string;
  newUsdtBalance: number;
  destinationConfirmed?: boolean;
  reachabilityVerified?: boolean;
  ledgerEntry?: LedgerEntry;
}

class JakeGroveCfoService {
  private client: any = config.binance.hasLiveKeys ? new Spot(config.binance.apiKey, config.binance.secretKey, { timeout: 8000 }) : null;
  private listeners: Array<(balances: any) => void> = [];
  private account: BinanceAccountStatus = {
    isConnected: false, isLiveApiKey: false, connectionStatus: 'BLOCKED_NO_KEYS',
    ownerEmail: 'UNVERIFIED', ownerName: 'Unverified account', binanceUid: '', accountType: 'NOT_CONNECTED',
    vipTier: 'UNVERIFIED', apiKeyMasked: '', pingLatencyMs: 0,
    usdtBalance: 0, usdcBalance: 0, btcBalance: 0, ethBalance: 0, bnbBalance: 0,
    totalEquityUsd: 0, availableMarginUsd: 0, autoSweepProfits: false,
    lastSyncAt: '', permissions: [], outboundEgressIp: '', whitelistedIp: '',
    verifiedDepositAddress: '', verifiedTronAddress: '', isSimulated: false,
    notes: 'No authenticated exchange response. Zero placeholders do not establish a zero account balance.',
  };
  public onBalanceChange(listener: (balances: any) => void) { this.listeners.push(listener); }
  public getCurrentBalances() { return { ...this.account }; }
  public hydrateState(_state: any): void { /* Financial balances are never restored from browser or saved UI state. */ }
  public async getAccountStatus(): Promise<BinanceAccountStatus> {
    if (!this.client) return { ...this.account };
    const started = performance.now();
    try {
      const response = await this.client.account();
      if (!Array.isArray(response.data?.balances)) throw new Error('Invalid account balance response.');
      const balance = (asset: string) => {
        const item = response.data.balances.find((b: any) => b.asset === asset);
        const value = item ? Number(item.free) : 0;
        if (!Number.isFinite(value) || value < 0) throw new Error('Invalid asset balance.');
        return value;
      };
      this.account = { ...this.account, isConnected: true, isLiveApiKey: true,
        connectionStatus: 'CONNECTED_LIVE', accountType: response.data.accountType || 'SPOT',
        usdtBalance: balance('USDT'), usdcBalance: balance('USDC'), btcBalance: balance('BTC'),
        ethBalance: balance('ETH'), bnbBalance: balance('BNB'), totalEquityUsd: 0,
        lastSyncAt: new Date().toISOString(), pingLatencyMs: performance.now() - started,
        permissions: response.data.permissions || [],
        notes: 'Free asset quantities verified by account API. Full USD valuation, UID ownership, deposit addresses and margin are unverified.',
      };
      for (const listener of this.listeners) listener({ ...this.account });
    } catch (err: any) {
      this.account = { ...this.account, isConnected: false, isLiveApiKey: false, connectionStatus: 'ERROR',
        usdtBalance: 0, usdcBalance: 0, btcBalance: 0, ethBalance: 0, bnbBalance: 0, totalEquityUsd: 0,
        notes: 'Exchange request failed; balances are unavailable. Retry after checking server credentials and connectivity.' };
    }
    return { ...this.account };
  }
  public async getDePINTickers(): Promise<DePINTicker[]> {
    if (!this.client) return [];
    try {
      const response = await this.client.ticker24hr();
      if (!Array.isArray(response.data)) return [];
      const pairs = new Set(['RENDERUSDT', 'TAOUSDT', 'AKTUSDT', 'IOUSDT', 'ATHUSDT', 'FETUSDT']);
      return response.data.filter((t: any) => pairs.has(t.symbol) && Number.isFinite(Number(t.lastPrice))).map((t: any) => ({
        symbol: t.symbol.replace('USDT', ''), pair: t.symbol, price: Number(t.lastPrice),
        change24h: Number(t.priceChangePercent), volume24h: String(t.quoteVolume),
        high24h: Number(t.highPrice), low24h: Number(t.lowPrice), source: 'BINANCE_LIVE_API', retrievedAt: new Date().toISOString(),
      }));
    } catch { return []; }
  }
  public async submitWithdrawal(_amount: number, _network: string, _address?: string): Promise<any> { throw new Error('BLOCKED: verified withdrawal settlement adapter required.'); }
  public async submitDeposit(_amount: number, _network: string, _address?: string): Promise<any> { throw new Error('BLOCKED: a deposit cannot be created by entering an amount.'); }
  public async sweepProfits(_amount: number): Promise<any> { throw new Error('BLOCKED: verified profit settlement adapter required.'); }
  public async borrowMargin(_amount: number): Promise<any> { throw new Error('BLOCKED: authenticated lending adapter required.'); }
  public toggleAutoSweep(): boolean { throw new Error('BLOCKED: automatic transfers are unsupported.'); }
}
export const jakeGroveCfoService = new JakeGroveCfoService();
