# GPU Arbitrage OS V14 — verified opportunity intake patch

## Scope
This is a **non-deployed, standalone engineering patch** prepared against the observed repository design. It does not create actual paying customers, retrieve job listings, confirm payments, or execute GPU workloads.

## Integration
1. Place `verifiedOpportunityEngine.ts` in `server/`.
2. Place `verifiedOpportunityEngine.test.ts` in `tests/` and update its import to `../server/verifiedOpportunityEngine.ts`.
3. Connect only **authorized** discovery APIs or public permitted listings. Keep API credentials on the server, respect rate limits and terms, and record original listing URLs and timestamps.
4. Persist opportunities in PostgreSQL with unique fingerprints; the current in-memory Map is suitable for a unit-tested domain model, **not production persistence**.
5. Protect opportunity mutations with existing owner/server authorization.
6. Only invoke `transition(..., 'FUNDED', ...)` after an authenticated payment provider independently verifies a captured or secured payment and matching customer order. A non-empty reference string is **not itself payment verification**.
7. Only invoke `transition(..., 'EXECUTING', ...)` after a real provider quote is authenticated, available and commercially permitted. Add atomic reservation and idempotency.
8. Add real settlement and workload-delivery adapters before moving to DELIVERED/RECONCILED. Never book projected margin as realized profit.
9. Run `npm test`, `npm run lint`, `npm run build`, `npm run security:check` in the actual repository after integration.

## Current blockers
- GitHub App refused branch creation with HTTP 403 Resource not accessible by integration.
- No external marketplace/customer payment credentials or live deployment were verified.
- This patch has not been committed, pushed or production-tested.
