/** Evidence-based opportunity intake. No claim of prepayment is inferred from listings. */
import { createHash, randomUUID } from 'node:crypto';

export type OpportunityState = 'DISCOVERED' | 'QUALIFIED' | 'ORDERED' | 'FUNDED' | 'EXECUTING' | 'DELIVERED' | 'RECONCILED' | 'REJECTED';
export interface OpportunityEvidence {
  sourceUrl: string;
  sourceName: string;
  observedAt: string;
  buyerName?: string;
  title: string;
  description: string;
  advertisedBudgetUsd?: number;
  deadline?: string;
}
export interface VerifiedOpportunity {
  id: string;
  fingerprint: string;
  evidence: OpportunityEvidence;
  state: OpportunityState;
  customerOrderId?: string;
  verifiedPaymentReference?: string;
  verifiedProviderQuoteId?: string;
  estimatedProviderCostUsd?: number;
  estimatedMarginUsd?: number;
  updatedAt: string;
}
const states: OpportunityState[] = ['DISCOVERED', 'QUALIFIED', 'ORDERED', 'FUNDED', 'EXECUTING', 'DELIVERED', 'RECONCILED'];
const validUrl = (url: string) => { const u = new URL(url); if (u.protocol !== 'https:' || !u.hostname.includes('.')) throw new Error('HTTPS public source URL required'); return u; };
export class VerifiedOpportunityEngine {
  private readonly records = new Map<string, VerifiedOpportunity>();
  private readonly fingerprints = new Map<string, string>();
  ingest(evidence: OpportunityEvidence): VerifiedOpportunity {
    validUrl(evidence.sourceUrl);
    if (!evidence.sourceName?.trim() || !evidence.title?.trim() || !evidence.description?.trim()) throw new Error('Source, title and description required');
    if (!Number.isFinite(Date.parse(evidence.observedAt))) throw new Error('Valid observation time required');
    if (evidence.advertisedBudgetUsd !== undefined && (!Number.isFinite(evidence.advertisedBudgetUsd) || evidence.advertisedBudgetUsd < 0)) throw new Error('Invalid advertised budget');
    const fingerprint = createHash('sha256').update(`${evidence.sourceUrl.trim().toLowerCase()}|${evidence.title.trim().toLowerCase()}`).digest('hex');
    const priorId = this.fingerprints.get(fingerprint);
    if (priorId) return structuredClone(this.records.get(priorId)!);
    const record: VerifiedOpportunity = { id: randomUUID(), fingerprint, evidence: structuredClone(evidence), state: 'DISCOVERED', updatedAt: new Date().toISOString() };
    this.records.set(record.id, record); this.fingerprints.set(fingerprint, record.id);
    return structuredClone(record);
  }
  get(id: string): VerifiedOpportunity | undefined { const r = this.records.get(id); return r && structuredClone(r); }
  list(): VerifiedOpportunity[] { return [...this.records.values()].map(r => structuredClone(r)); }
  transition(id: string, next: OpportunityState, proof: { customerOrderId?: string; verifiedPaymentReference?: string; verifiedProviderQuoteId?: string; estimatedProviderCostUsd?: number; estimatedMarginUsd?: number } = {}): VerifiedOpportunity {
    const current = this.records.get(id); if (!current) throw new Error('Unknown opportunity');
    if (next === 'REJECTED') { if (['EXECUTING','DELIVERED','RECONCILED'].includes(current.state)) throw new Error('Cannot reject executing or completed work'); }
    else if (states.indexOf(next) !== states.indexOf(current.state) + 1) throw new Error('Invalid opportunity transition');
    if (next === 'ORDERED' && !proof.customerOrderId?.trim()) throw new Error('Customer order evidence required');
    if (next === 'FUNDED' && !proof.verifiedPaymentReference?.trim()) throw new Error('Independently verified payment reference required');
    if (next === 'EXECUTING') {
      if (!current.verifiedPaymentReference || !proof.verifiedProviderQuoteId?.trim()) throw new Error('Funding and verified provider quote required');
      if (!Number.isFinite(proof.estimatedProviderCostUsd) || (proof.estimatedProviderCostUsd ?? -1) < 0 || !Number.isFinite(proof.estimatedMarginUsd) || (proof.estimatedMarginUsd ?? -1) <= 0) throw new Error('Positive verified margin estimate required');
    }
    // Callers MUST validate proof against their authenticated payment/order/provider adapters before calling this method.
    const updated = { ...current, ...proof, state: next, updatedAt: new Date().toISOString() };
    this.records.set(id, updated); return structuredClone(updated);
  }
}
